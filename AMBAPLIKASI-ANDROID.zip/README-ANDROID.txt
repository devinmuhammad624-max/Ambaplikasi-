AMBAPLIKASI Android project
App name: AMBA KASIR
Package: com.ambaplikasi
The web dashboard is bundled in app/src/main/assets/index.html and opened in a native Android WebView.
Build with Android Studio/Gradle using JDK 17 and Android SDK 35.
